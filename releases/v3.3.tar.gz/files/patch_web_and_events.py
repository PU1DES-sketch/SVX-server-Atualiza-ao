#!/usr/bin/env python3
import json
from pathlib import Path

INDEX = Path("/var/www/html/repeater/index.php")
SALVAR = Path("/var/www/html/repeater/salvar.php")
EVENTS = Path("/usr/share/svxlink/events.d/local/RepeaterLogic.tcl")
SUDOERS = Path("/etc/sudoers.d/repeater-update")


def patch_index():
    if not INDEX.exists():
        return
    txt = INDEX.read_text(encoding="utf-8", errors="ignore")

    compact_css = """
        .config-grid { gap: 9px 12px !important; align-items: end; }
        .box { padding: 12px !important; margin-bottom: 14px !important; }
        .box h3 { margin-bottom: 10px !important; padding-bottom: 6px !important; }
        .field-group { margin-bottom: 4px !important; }
        .field-group label { margin-bottom: 3px !important; }
        .field-group input,
        .field-group select { width: 80% !important; padding: 5px 7px !important; min-height: 29px; }
        .field-group input[type="range"],
        .field-group input[type="file"],
        .wifi-actions select,
        .wide-2 input,
        .wide-2 select,
        .system-panel input,
        .system-panel select { width: 100% !important; }
        .section-head { padding: 5px 10px !important; margin-top: 7px !important; }
        .btn-save { margin-top: 14px !important; padding: 10px !important; }
"""
    if ".config-grid { gap: 9px 12px !important;" not in txt:
        marker = ".hint { display: block; margin-top: 4px; color: #6b7280; font-size: 10px; }"
        if marker in txt:
            txt = txt.replace(marker, marker + compact_css, 1)
        else:
            txt = txt.replace("</style>", compact_css + "\n</style>", 1)

    dtmf_css = """
        .system-grid3 { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 10px; }
        .system-card { background: #fff; border: 1px solid #e5e7eb; border-radius: 5px; padding: 10px; min-height: 78px; }
        .system-card .system-actions { margin-top: 8px; }
        .btn-danger { background: #b91c1c !important; }
        .saving-bar { height: 16px; background:#111827; border-radius:999px; overflow:hidden; margin-top:14px; border:1px solid #374151; }
        .saving-bar span { display:block; height:100%; width:100%; background:linear-gradient(90deg,#22c55e,#38bdf8); animation:savingPulse 1s infinite; }
        @keyframes savingPulse { 50% { opacity:.45; } }
"""
    if ".system-grid3" not in txt:
        txt = txt.replace("</style>", dtmf_css + "\n</style>", 1)
    action_css = """
        .btn-danger { background: #b91c1c !important; }
        .saving-bar { height: 16px; background:#111827; border-radius:999px; overflow:hidden; margin-top:14px; border:1px solid #374151; }
        .saving-bar span { display:block; height:100%; width:100%; background:linear-gradient(90deg,#22c55e,#38bdf8); animation:savingPulse 1s infinite; }
        @keyframes savingPulse { 50% { opacity:.45; } }
"""
    if ".saving-bar" not in txt:
        txt = txt.replace("</style>", action_css + "\n</style>", 1)

    css_marker = ".btn-update { background: #34495e; color: white; border: none; padding: 5px 10px; border-radius: 3px; font-size: 10px; cursor: pointer; }"
    if ".wide-2" not in txt and css_marker in txt:
        txt = txt.replace(css_marker, css_marker + """
        .wide-2 { grid-column: span 2; }
        .full-width { grid-column: span 3; }
        .system-panel { background: #f8fafc; border: 1px solid #e5e7eb; border-radius: 5px; padding: 12px; }
        .system-row { display: flex; align-items: center; justify-content: space-between; gap: 14px; flex-wrap: wrap; }
        .system-title { font-size: 11px; font-weight: bold; color: #475569; margin-bottom: 8px; text-transform: uppercase; }
        .system-actions { display: flex; gap: 8px; flex-wrap: wrap; align-items: center; }
        .system-grid3 { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 10px; }
        .system-card { background: #fff; border: 1px solid #e5e7eb; border-radius: 5px; padding: 10px; min-height: 78px; }
        .system-card .system-actions { margin-top: 8px; }
        .checkline { display: inline-flex; align-items: center; gap: 7px; font-size: 12px; color: #334155; font-weight: bold; }
        .checkline input { width: auto; }
""", 1)

    start = txt.find('<div class="section-head">Rede e Atualiza')
    if start == -1:
        start = txt.find('<div class="section-head">Rede e Sistema')
    if start != -1:
        end = txt.find('<button type="submit" class="btn-save">', start)
        if end != -1:
            block = '''<div class="section-head">Rede e Sistema</div>
                        <div class="field-group wide-2">
                            <label>Rede Wi-Fi:</label>
                            <div class="wifi-actions">
                                <select name="wifi_ssid" id="wifi_ssid" data-current="<?php echo htmlspecialchars($config['wifi_ssid'] ?? '', ENT_QUOTES); ?>">
                                    <option value="<?php echo htmlspecialchars($config['wifi_ssid'] ?? '', ENT_QUOTES); ?>"><?php echo htmlspecialchars(($config['wifi_ssid'] ?? '') ?: 'Buscar redes disponiveis'); ?></option>
                                </select>
                                <button type="button" class="btn-mini" onclick="loadWifiNetworks()">BUSCAR</button>
                            </div>
                            <span class="hint" id="wifi_hint">Se nao conectar em nenhum Wi-Fi no boot, o AP REPETIDOR-CONFIG sera ativado.</span>
                        </div>
                        <div class="field-group"><label>Senha Wi-Fi:</label><input type="password" name="wifi_pass" placeholder="Digite a senha da rede selecionada"></div>
                        <div class="field-group full-width system-panel">
                            <div class="system-grid3">
                                <div class="system-card">
                                    <div class="system-title">Automacao</div>
                                    <label class="checkline"><input type="checkbox" name="time_announce_enabled" value="1" <?php echo !empty($config['time_announce_enabled']) && $config['time_announce_enabled'] !== '0' ? 'checked' : ''; ?>> Falar hora certa a cada hora</label>
                                </div>
                                <div class="system-card">
                                    <div class="system-title">DTMF</div>
                                    <div class="system-actions">
                                        <button type="button" class="btn-update" onclick="window.location.href='dtmf.php'">CONFIGURAR DTMF</button>
                                    </div>
                                </div>
                                <div class="system-card">
                                    <div class="system-title">Manutencao</div>
                                    <div class="system-actions">
                                        <button type="button" class="btn-update" onclick="window.location.href='update.php'">BUSCAR ATUALIZACOES</button>
                                        <button type="button" class="btn-update" onclick="window.location.href='backup.php'">BACKUP</button>
                                        <button type="button" class="btn-update" onclick="window.location.href='restore.php'">RESTAURAR BACKUP</button>
                                        <button type="button" class="btn-update" onclick="window.location.href='senha.php'">ALTERAR SENHA</button>
                                        <button type="button" class="btn-update btn-danger" onclick="window.location.href='shutdown.php'">DESLIGAR</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        '''
            txt = txt[:start] + block + txt[end:]
    old_submit = """function submitConfirm() {
  allowSubmit = true;
  document.getElementById('configForm').submit();
}"""
    new_submit = """function submitConfirm() {
  allowSubmit = true;
  const modal = document.getElementById('confirmModal');
  const panel = modal ? modal.querySelector('div') : null;
  if (panel) {
    panel.innerHTML = '<h2>Salvando configuracoes</h2><p>Aplicando ajustes e reiniciando a repetidora. Aguarde alguns segundos.</p><div class=\"saving-bar\"><span></span></div>';
  }
  document.getElementById('configForm').submit();
}"""
    if old_submit in txt:
        txt = txt.replace(old_submit, new_submit, 1)
    INDEX.write_text(txt, encoding="utf-8")


def patch_salvar():
    if not SALVAR.exists():
        return
    txt = SALVAR.read_text(encoding="utf-8", errors="ignore")
    marker = "foreach ($_POST as $key => $value) {\n    $config[$key] = clean($value);\n}\n"
    insert = marker + "\n$config['time_announce_enabled'] = isset($_POST['time_announce_enabled']) ? '1' : '0';\n"
    if "time_announce_enabled" not in txt:
        txt = txt.replace(marker, insert, 1)
    apply_line = 'shell_exec("sudo /usr/local/bin/repeater-apply-config $audioArg >/tmp/repeater_apply_config.log 2>/tmp/repeater_apply_config_error.log");'
    dtmf_line = "shell_exec('sudo /usr/local/bin/repeater-dtmf-action apply >/tmp/repeater_dtmf_apply.log 2>/tmp/repeater_dtmf_apply_error.log');"
    if apply_line in txt and "repeater-dtmf-action apply" not in txt:
        txt = txt.replace(apply_line, apply_line + "\n" + dtmf_line, 1)
    SALVAR.write_text(txt, encoding="utf-8")


def patch_events():
    if not EVENTS.exists():
        return
    txt = EVENTS.read_text(encoding="utf-8", errors="ignore")
    if "bdnet_time_announce" not in txt:
        proc = r'''

proc bdnet_time_announce {} {
  set flag "/tmp/repeater_time_announce"
  if {![file exists $flag]} {
    return
  }
  variable repeater_is_up
  if {[info exists repeater_is_up] && $repeater_is_up == 1} {
    return
  }
  set wav [string trim [exec cat $flag]]
  if {[file exists $wav]} {
    puts "BDNET: falando hora certa $wav"
    playSilence 300
    playFile $wav
    playSilence 300
    file delete -force $flag
  }
}
'''
        txt = txt.replace("\nproc checkPeriodicIdentify {} {", proc + "\nproc checkPeriodicIdentify {} {", 1)
    if "bdnet_dtmf_cmd_received" not in txt:
        proc = r'''

proc bdnet_dtmf_cmd_received {cmd} {
  set clean [string toupper [string map {"#" "" " " ""} $cmd]]
  if {$clean == ""} {
    return 0
  }
  if {[catch {exec /usr/local/bin/repeater-dtmf-action $clean} result]} {
    puts "BDNET DTMF: erro ao executar comando $clean: $result"
    return 0
  }
  if {[string trim $result] != ""} {
    puts "BDNET DTMF: $result"
    return 1
  }
  return 0
}

proc dtmf_cmd_received {cmd} {
  if {[bdnet_dtmf_cmd_received $cmd]} {
    return 1
  }
  if {[llength [info commands Logic::dtmf_cmd_received]]} {
    return [Logic::dtmf_cmd_received $cmd]
  }
  return 0
}
'''
        insert_at = txt.find("\nproc checkPeriodicIdentify {} {")
        if insert_at != -1:
            txt = txt[:insert_at] + proc + txt[insert_at:]
        else:
            txt += proc
    old = "proc checkPeriodicIdentify {} {\n  Logic::checkPeriodicIdentify\n}"
    new = "proc checkPeriodicIdentify {} {\n  Logic::checkPeriodicIdentify\n  bdnet_time_announce\n}"
    if old in txt:
        txt = txt.replace(old, new, 1)
    EVENTS.write_text(txt, encoding="utf-8")


def patch_sudoers():
    SUDOERS.write_text(
        "www-data ALL=(root) NOPASSWD: /usr/local/bin/repeater-update-apply\n"
        "www-data ALL=(root) NOPASSWD: /usr/local/bin/repeater-update-check\n"
        "www-data ALL=(root) NOPASSWD: /usr/local/bin/repeater-backup\n"
        "www-data ALL=(root) NOPASSWD: /usr/local/bin/repeater-restore *\n"
        "www-data ALL=(root) NOPASSWD: /usr/local/bin/repeater-dtmf-config-save *\n"
        "www-data ALL=(root) NOPASSWD: /usr/local/bin/repeater-dtmf-action apply\n"
        "www-data ALL=(root) NOPASSWD: /usr/sbin/shutdown -h now\n"
        "www-data ALL=(root) NOPASSWD: /sbin/shutdown -h now\n",
        encoding="utf-8",
    )
    SUDOERS.chmod(0o440)


patch_index()
patch_salvar()
patch_events()
patch_sudoers()
