#!/bin/sh
set -eu

VERSION="5.6"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP_DIR="/var/backups/repeater/update-$VERSION-$STAMP"

backup_file() {
  source="$1"
  target="$BACKUP_DIR$source"
  if [ -f "$source" ]; then
    mkdir -p "$(dirname "$target")"
    cp -a "$source" "$target"
  fi
}

backup_file /usr/local/bin/repeater-apply-config
backup_file /usr/share/svxlink/events.d/local/RepeaterLogic.tcl
backup_file /etc/svxlink/svxlink.conf

python3 - <<'PY'
import re
from pathlib import Path

apply = Path('/usr/local/bin/repeater-apply-config')
logic = Path('/usr/share/svxlink/events.d/local/RepeaterLogic.tcl')
svx = Path('/etc/svxlink/svxlink.conf')

if not apply.exists() or not logic.exists() or not svx.exists():
    raise SystemExit('Arquivos esperados do ProtoRadio nao foram encontrados; atualizacao cancelada')

apply_text = apply.read_text(encoding='utf-8')
rgr_pattern = r'(?m)^txt = set_value\(txt, "RepeaterLogic", "RGR_SOUND_DELAY", [^)]+\)$'
rgr_line = 'txt = set_value(txt, "RepeaterLogic", "RGR_SOUND_DELAY", "0")'
if not re.search(rgr_pattern, apply_text):
    raise SystemExit('Formato do aplicador desconhecido; atualizacao cancelada')
apply_text = re.sub(rgr_pattern, rgr_line, apply_text, count=1)

sql_pattern = r'(?m)^txt = set_value\(txt, "Rx1", "SQL_HANGTIME", [^)]+\)$'
sql_line = 'txt = set_value(txt, "Rx1", "SQL_HANGTIME", "0")'
if re.search(sql_pattern, apply_text):
    apply_text = re.sub(sql_pattern, sql_line, apply_text, count=1)
else:
    apply_text = apply_text.replace(rgr_line, rgr_line + '\n' + sql_line, 1)
apply.write_text(apply_text, encoding='utf-8')

svx_text = svx.read_text(encoding='utf-8')
svx_text = re.sub(r'(?m)^\s*RGR_SOUND_DELAY=.*$', 'RGR_SOUND_DELAY=0', svx_text)
svx_text = re.sub(r'(?m)^\s*SQL_HANGTIME=.*$', 'SQL_HANGTIME=0', svx_text)
svx.write_text(svx_text, encoding='utf-8')

logic_text = logic.read_text(encoding='utf-8')
marker = 'set tone_level 320\n  puts "BDNET: bip de cortesia $bip"'
replacement = '''set tone_level 320
  # Keep RF keyed with digital silence instead of retransmitting receiver tail noise.
  set silent_ms [get_config_value "hang_time" "1500"]
  if {![string is integer -strict $silent_ms]} {
    set silent_ms 1500
  }
  set silent_ms [expr {max(0, min($silent_ms, 10000))}]
  if {$silent_ms > 0} {
    playSilence $silent_ms
  }
  puts "BDNET: bip de cortesia $bip"'''
if marker in logic_text:
    logic_text = logic_text.replace(marker, replacement, 1)
elif 'Keep RF keyed with digital silence' not in logic_text and 'Keep the RF transmitter keyed with digital silence' not in logic_text:
    raise SystemExit('Formato do evento de bip desconhecido; atualizacao cancelada')
logic.write_text(logic_text, encoding='utf-8')
PY

printf '%s\n' "$VERSION" >/etc/repeater/version
systemctl restart svxlink
echo "Atualizacao $VERSION instalada."
echo "Rabicho silencioso instalado com compatibilidade para base 4.5."
echo "Backup: $BACKUP_DIR"
