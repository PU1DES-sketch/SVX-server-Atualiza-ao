<?php
require_once __DIR__ . '/auth.php';
require_login();

$message = null;
$output = null;

function backup_files() {
    $files = glob('/var/backups/repeater/*.tar.gz') ?: [];
    rsort($files);
    return $files;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'create') {
    $output = shell_exec('sudo /usr/local/bin/repeater-backup 2>&1');
    $message = 'Backup gerado. Confira a lista abaixo.';
}

if (isset($_GET['download'])) {
    $name = basename($_GET['download']);
    $path = '/var/backups/repeater/' . $name;
    if (is_file($path) && preg_match('/\.tar\.gz$/', $name)) {
        header('Content-Type: application/gzip');
        header('Content-Disposition: attachment; filename="' . $name . '"');
        header('Content-Length: ' . filesize($path));
        readfile($path);
        exit;
    }
    $message = 'Arquivo de backup nao encontrado.';
}

$files = backup_files();
?>
<!doctype html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Backup</title>
<style>
body{font-family:Arial,sans-serif;background:#111827;color:#e5e7eb;margin:0;padding:22px}
a{color:#7dd3fc}.box{max-width:900px;background:#1f2937;border:1px solid #374151;border-radius:8px;padding:18px}
button,.btn{display:inline-block;background:#2563eb;color:white;border:0;border-radius:7px;padding:10px 14px;font-weight:700;text-decoration:none;cursor:pointer}
.muted{color:#9ca3af}.ok{color:#22c55e}table{width:100%;border-collapse:collapse;margin-top:14px}td,th{border-bottom:1px solid #374151;padding:10px;text-align:left}
pre{white-space:pre-wrap;background:#0b1220;border:1px solid #334155;border-radius:7px;padding:12px}
</style>
</head>
<body>
<div class="box">
<p><a href="index.php">Voltar</a></p>
<h1>Backup da repetidora</h1>
<p class="muted">O backup guarda as configuracoes principais para restaurar depois de gravar uma nova imagem.</p>
<form method="post">
  <input type="hidden" name="action" value="create">
  <button type="submit">Gerar backup agora</button>
  <a class="btn" href="restore.php">Restaurar backup</a>
</form>
<?php if ($message): ?><p class="ok"><?php echo htmlspecialchars($message); ?></p><?php endif; ?>
<?php if ($output): ?><pre><?php echo htmlspecialchars($output); ?></pre><?php endif; ?>
<h2>Backups disponiveis</h2>
<?php if (!$files): ?>
  <p class="muted">Nenhum backup encontrado.</p>
<?php else: ?>
  <table>
    <thead><tr><th>Arquivo</th><th>Tamanho</th><th>Data</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($files as $file): $name = basename($file); ?>
      <tr>
        <td><?php echo htmlspecialchars($name); ?></td>
        <td><?php echo number_format(filesize($file) / 1024, 1, ',', '.'); ?> KB</td>
        <td><?php echo date('d/m/Y H:i:s', filemtime($file)); ?></td>
        <td><a class="btn" href="?download=<?php echo urlencode($name); ?>">Baixar</a></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
<?php endif; ?>
</div>
</body>
</html>
