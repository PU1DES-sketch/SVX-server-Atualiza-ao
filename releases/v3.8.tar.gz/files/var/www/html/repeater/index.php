<?php
require_once __DIR__ . "/auth.php"; require_login();
$config_path = '/etc/repeater/config.json';
$config = file_exists($config_path) ? json_decode(file_get_contents($config_path), true) : [];
$cpu_temp = shell_exec("vcgencmd measure_temp | egrep -o '[0-9]*\\\.[0-9]*'") . "°C";
$mem_info = shell_exec("free -m | awk 'NR==2{printf \"%s/%s MB\", $3,$2}'");
$local_ip = $_SERVER['SERVER_ADDR'] ?? '127.0.0.1';
$server_status = (!empty($config['server_ip'])) ? $config['server_ip'] : "Desconectado";
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>SVX MASTER PANEL v2.0</title>
    <style>
        * { box-sizing: border-box; }
        body { font-family: 'Segoe UI', Arial, sans-serif; margin: 0; display: flex; background: #cbd5e0; color: #333; height: 100vh; overflow: hidden; }
        #sidebar { width: 200px; background: #111; color: #fff; display: flex; flex-direction: column; box-shadow: 2px 0 10px rgba(0,0,0,0.3); }
        #sidebar .header { padding: 25px 10px; text-align: center; background: #000; font-weight: bold; border-bottom: 1px solid #222; color: #3498db; letter-spacing: 1px; }
        .menu-item { padding: 15px 20px; cursor: pointer; border-bottom: 1px solid #1a1a1a; transition: 0.2s; font-size: 13px; color: #999; }
        .menu-item:hover { background: #222; color: #fff; }
        .menu-item.active { background: #3498db; color: #fff; border-right: 4px solid #fff; }
        #main { flex: 1; overflow-y: auto; padding: 20px; }
        .page { display: none; }
        .page.active { display: block; }
        .status-bar { display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 10px; margin-bottom: 20px; }
        .stat-card { background: #fff; padding: 12px; border-radius: 4px; border-top: 3px solid #3498db; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .stat-card small { display: block; font-size: 9px; color: #888; text-transform: uppercase; margin-bottom: 4px; }
        .stat-card b { font-size: 13px; color: #2c3e50; }
        #tx-status { padding: 12px; text-align: center; border-radius: 4px; font-weight: bold; margin-bottom: 20px; background: #7f8c8d; color: #fff; text-transform: uppercase; font-size: 14px; }
        .tx-on { background: #c0392b !important; animation: blink 1s infinite; }
        @keyframes blink { 50% { opacity: 0.6; } }
        .box { background: #fff; border-radius: 4px; padding: 15px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); margin-bottom: 20px; }
        .box h3 { margin: 0 0 15px 0; font-size: 14px; border-bottom: 1px solid #eee; padding-bottom: 8px; color: #2c3e50; }
        .config-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; }
        .field-group { margin-bottom: 8px; }
        .field-group label { display: block; font-size: 11px; font-weight: bold; margin-bottom: 4px; color: #666; }
        .field-group input, .field-group select { width: 100%; padding: 7px; border: 1px solid #ddd; border-radius: 3px; font-size: 12px; background: #fafafa; }
        .section-head { grid-column: span 3; background: #f8f9fa; padding: 6px 12px; font-size: 11px; font-weight: bold; margin-top: 10px; border-radius: 2px; color: #3498db; border-left: 3px solid #3498db; }
        .btn-save { background: #27ae60; color: #fff; border: none; padding: 12px; border-radius: 3px; cursor: pointer; font-weight: bold; width: 100%; margin-top: 20px; font-size: 14px; }
        .btn-update { background: #34495e; color: white; border: none; padding: 5px 10px; border-radius: 3px; font-size: 10px; cursor: pointer; }
        .wide-2 { grid-column: span 2; }
        .full-width { grid-column: span 3; }
        .system-panel { background: #f8fafc; border: 1px solid #e5e7eb; border-radius: 5px; padding: 12px; }
        .system-row { display: flex; align-items: center; justify-content: space-between; gap: 14px; flex-wrap: wrap; }
        .system-title { font-size: 11px; font-weight: bold; color: #475569; margin-bottom: 8px; text-transform: uppercase; }
        .system-actions { display: flex; gap: 8px; flex-wrap: wrap; align-items: center; }
        .checkline { display: inline-flex; align-items: center; gap: 7px; font-size: 12px; color: #334155; font-weight: bold; }
        .checkline input { width: auto; }


        .brand-footer { margin-top: auto; padding: 12px 10px; font-size: 10px; color: #6b7280; text-align: center; border-top: 1px solid #222; line-height: 1.4; }
        .watermark { position: fixed; right: 14px; bottom: 8px; color: rgba(17,24,39,.42); font-size: 11px; letter-spacing: .2px; pointer-events: none; }
        .wifi-actions { display: flex; gap: 6px; align-items: center; }
        .wifi-actions select { flex: 1; min-width: 0; }
        .btn-mini { background: #0f766e; color: white; border: none; padding: 7px 9px; border-radius: 3px; font-size: 10px; cursor: pointer; white-space: nowrap; }
        .hint { display: block; margin-top: 4px; color: #6b7280; font-size: 10px; }
        .config-grid { gap: 9px 12px !important; align-items: end; }
        .box { padding: 12px !important; margin-bottom: 14px !important; }
        .box h3 { margin-bottom: 10px !important; padding-bottom: 6px !important; }
        .field-group { margin-bottom: 4px !important; }
        .field-group label { margin-bottom: 3px !important; }
        .field-group input,
        .field-group select { width: 80% !important; padding: 5px 7px !important; min-height: 29px; }
        .field-group input[type="range"],
        .field-group input[type="file"],
        .wifi-actions select,
        .wide-2 input,
        .wide-2 select,
        .system-panel input,
        .system-panel select { width: 100% !important; }
        .section-head { padding: 5px 10px !important; margin-top: 7px !important; }
        .btn-save { margin-top: 14px !important; padding: 10px !important; }

        table { width: 100%; border-collapse: collapse; font-size: 11px; }
        th { text-align: left; background: #f4f4f4; padding: 8px; border-bottom: 2px solid #ddd; }
        td { padding: 8px; border-bottom: 1px solid #eee; }
    
        .system-grid3 { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 10px; }
        .system-card { background: #fff; border: 1px solid #e5e7eb; border-radius: 5px; padding: 10px; min-height: 78px; }
        .system-card .system-actions { margin-top: 8px; }


        .btn-danger { background: #b91c1c !important; }
        .saving-bar { height: 16px; background:#111827; border-radius:999px; overflow:hidden; margin-top:14px; border:1px solid #374151; }
        .saving-bar span { display:block; height:100%; width:100%; background:linear-gradient(90deg,#22c55e,#38bdf8); animation:savingPulse 1s infinite; }
        @keyframes savingPulse { 50% { opacity:.45; } }

</style>
</head>
<body>
    <div id="sidebar">
        <div class="header">SVX MASTER</div>
        <div class="menu-item active" onclick="showPage('dash', this)">DASHBOARD</div>
        <div class="menu-item" onclick="showPage('config', this)">CONFIGURAÇÕES</div>
        <div class="menu-item" onclick="location.reload()">ATUALIZAR PAINEL</div>
        <div class="brand-footer">Produzido por PI<br>Desenvolvido por PU1DES</div>
    </div>
    <div id="main">
        <div id="dash" class="page active">
            <div id="tx-status">SISTEMA EM STANDBY</div>
            <div class="status-bar">
                <div class="stat-card"><small>CPU Temp</small><b id="cpu-temp"><?php echo $cpu_temp; ?></b></div>
                <div class="stat-card"><small>Memória</small><b><?php echo $mem_info; ?></b></div>
                <div class="stat-card"><small>IP Local</small><b><?php echo $local_ip; ?></b></div>
                <div class="stat-card"><small>Servidor</small><b><?php echo $server_status; ?></b></div>
                <div class="stat-card"><small>Frequência</small><b><?php echo $config['frequencia'] ?? '---.---'; ?> MHz</b></div>
            </div>
            <div class="box">
                <h3>Últimas 20 Chamadas</h3>
                <table>
                    <thead><tr><th>Horário</th><th>Duração</th><th>Origem</th><th>Status</th></tr></thead>
                    <tbody id="call-log"><tr><td colspan="4" style="text-align:center; padding:20px; color:#999;">Aguardando tráfego...</td></tr></tbody>
                </table>
            </div>
        </div>
        <div id="config" class="page">
            <div class="box">
                <h3>Ajustes da Repetidora</h3>
                <form action="salvar.php" method="post" enctype="multipart/form-data" id="configForm">
                    <div class="config-grid">
                        <div class="section-head">Identificação e Rádio</div>
                        <div class="field-group"><label>Indicativo (CW):</label><input type="text" name="callsign" value="<?php echo $config['callsign'] ?? ''; ?>"></div>
                        <div class="field-group"><label>Intervalo CW (Min):</label><input type="number" name="id_interval" value="<?php echo $config['id_interval'] ?? ''; ?>"></div>
                        <div class="field-group"><label>TOT TX (Seg):</label><input type="number" name="tot" value="<?php echo $config['tot'] ?? ''; ?>"></div>
                        <div class="field-group"><label>Frequência (MHz):</label><input type="text" name="frequencia" value="<?php echo $config['frequencia'] ?? ''; ?>"></div>
                        <div class="field-group"><label>Rabicho / HangTime (ms):</label><input type="number" name="hang_time" value="<?php echo $config['hang_time'] ?? ''; ?>"></div>
                        <div class="field-group">
                            <label>Bip de Cortesia:</label>
                            <select name="bip_cortesia">
                                <?php
                                $bips = ["Simples", "Motorola", "Kenwood", "Icom", "Yaesu", "Hytera", "Harris", "Tait", "Sepura", "Custom"];
                                foreach($bips as $b) {
                                    $sel = (isset($config['bip_cortesia']) && $config['bip_cortesia'] == strtolower($b)) ? "selected" : "";
                                    echo "<option value='".strtolower($b)."' $sel>$b</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="section-head">Conexão com Servidor (Refletor)</div>
                        <div class="field-group"><label>Endereço IP / Host:</label><input type="text" name="server_ip" value="<?php echo $config['server_ip'] ?? ''; ?>"></div>
                        <div class="field-group"><label>Porta:</label><input type="number" name="server_port" value="<?php echo $config['server_port'] ?? '5210'; ?>"></div>
                        <div class="field-group"><label>Senha do Servidor:</label><input type="password" name="server_pass" value="<?php echo $config['server_pass'] ?? ''; ?>"></div>
                        <div class="section-head">Hardware e Áudio Digital</div>
                        <div class="field-group"><label>Pino Cooler (GPIO):</label><input type="number" name="gpio_cooler" value="<?php echo $config['gpio_cooler'] ?? ''; ?>"></div>
                        <div class="field-group"><label>Tempo Cooler (Seg):</label><input type="number" name="cooler_tempo" value="<?php echo $config['cooler_tempo'] ?? ''; ?>"></div>
                        <div class="field-group"><label>Ganho Mic (USB):</label><input type="range" name="mic_gain" min="0" max="100" value="<?php echo $config['mic_gain'] ?? 50; ?>"></div>
                        <div class="field-group"><label>Volume Spk (USB):</label><input type="range" name="spk_vol" min="0" max="100" value="<?php echo $config['spk_vol'] ?? 50; ?>"></div>
                        <div class="field-group"><label>Modo ID:</label>
<select name="id_mode">
  <option value="cw" <?php if(($config['id_mode'] ?? 'cw') == 'cw') echo 'selected'; ?>>CW</option>
  <option value="audio" <?php if(($config['id_mode'] ?? 'cw') == 'audio') echo 'selected'; ?>>Áudio</option>
  <option value="alt" <?php if(($config['id_mode'] ?? 'cw') == 'alt') echo 'selected'; ?>>Alternado</option>
</select>
</div>
                        <div class="field-group"><label>Arquivo MP3:</label><input type="file" name="audio_file" style="font-size:10px;"></div>
                        <div class="section-head">Rede e Sistema</div>
                        <div class="field-group wide-2">
                            <label>Rede Wi-Fi:</label>
                            <div class="wifi-actions">
                                <select name="wifi_ssid" id="wifi_ssid" data-current="<?php echo htmlspecialchars($config['wifi_ssid'] ?? '', ENT_QUOTES); ?>">
                                    <option value="<?php echo htmlspecialchars($config['wifi_ssid'] ?? '', ENT_QUOTES); ?>"><?php echo htmlspecialchars(($config['wifi_ssid'] ?? '') ?: 'Buscar redes disponiveis'); ?></option>
                                </select>
                                <button type="button" class="btn-mini" onclick="loadWifiNetworks()">BUSCAR</button>
                            </div>
                            <span class="hint" id="wifi_hint">Se nao conectar em nenhum Wi-Fi no boot, o AP REPETIDOR-CONFIG sera ativado.</span>
                        </div>
                        <div class="field-group"><label>Senha Wi-Fi:</label><input type="password" name="wifi_pass" placeholder="Digite a senha da rede selecionada"></div>
                        <div class="field-group full-width system-panel">
                            <div class="system-grid3">
                                <div class="system-card">
                                    <div class="system-title">Automacao</div>
                                    <label class="checkline"><input type="checkbox" name="time_announce_enabled" value="1" <?php echo !empty($config['time_announce_enabled']) && $config['time_announce_enabled'] !== '0' ? 'checked' : ''; ?>> Falar hora certa a cada hora</label>
                                    <button type="button" class="btn-update" onclick="testTimeAnnounce()">FALAR AGORA</button>
                                    <div class="hint" id="time_announce_result"></div>
                                </div>
                                <div class="system-card">
                                    <div class="system-title">DTMF</div>
                                    <div class="system-actions">
                                        <button type="button" class="btn-update" onclick="window.location.href='dtmf.php'">CONFIGURAR DTMF</button>
                                    </div>
                                </div>
                                <div class="system-card">
                                    <div class="system-title">Manutencao</div>
                                    <div class="system-actions">
                                        <button type="button" class="btn-update" onclick="window.location.href='update.php'">BUSCAR ATUALIZACOES</button>
                                        <button type="button" class="btn-update" onclick="window.location.href='backup.php'">BACKUP</button>
                                        <button type="button" class="btn-update" onclick="window.location.href='restore.php'">RESTAURAR BACKUP</button>
                                        <button type="button" class="btn-update" onclick="window.location.href='senha.php'">ALTERAR SENHA</button>
                                        <button type="button" class="btn-update btn-danger" onclick="window.location.href='shutdown.php'">DESLIGAR</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="btn-save">SALVAR E REINICIAR REPETIDORA</button>
                </form>
            </div>
        </div>
    </div>
    <script>
        // CORREÇÃO: havia tags <script> duplicadas aqui
        async function testTimeAnnounce() {
            const target = document.getElementById('time_announce_result');
            if (target) target.textContent = 'Preparando fala da hora...';
            try {
                const res = await fetch('time_announce_now.php', { method: 'POST', cache: 'no-store' });
                const data = await res.json();
                if (target) target.textContent = data.message || (data.ok ? 'Hora preparada.' : 'Falha ao preparar hora.');
            } catch (err) {
                if (target) target.textContent = 'Falha ao chamar o teste da hora.';
            }
        }

        function showPage(id, btn) {
            document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
            document.querySelectorAll('.menu-item').forEach(m => m.classList.remove('active'));
            document.getElementById(id).classList.add('active');
            btn.classList.add('active');
        }
        function updateStatus() {
            fetch('status.php')
                .then(r => r.json())
                .then(data => {
                    liveRx = data;
                    document.getElementById('cpu-temp').innerText = data.temp;
                    const txBox = document.getElementById('tx-status');
                    if(data.tx === "ON" || data.rx_live) {
                        txBox.innerText = data.rx_origem ? ("REPETIDORA RECEBENDO - " + data.rx_origem) : "REPETIDORA EM TRANSMISSÃO (TX)";
                        txBox.classList.add('tx-on');
                    } else if(data.sql === "1" || data.sql === 1 || data.rx === "ON") {
                        txBox.innerText = "REPETIDORA RECEBENDO (COS)";
                        txBox.classList.add('tx-on');
                    } else {
                        txBox.innerText = "SISTEMA EM STANDBY";
                        txBox.classList.remove('tx-on');
                    }
                })
                .catch(e => console.log("Aguardando dados do controlador..."));
        }
let liveRx = null;

function updateLogs() {
    Promise.all([
        fetch('log_parser.php').then(r => r.json()),
        fetch('status.php').then(r => r.json())
    ]).then(([data, status]) => {
        let html = '';

        if (status.rx_live) {
            html += `<tr style="background:#d8f8df; font-weight:bold;">
                <td>${status.rx_inicio_txt}</td>
                <td>${status.rx_duracao} s</td>
                <td>${status.rx_origem || 'Local'}</td>
                <td style="color:#078b28;">● AO VIVO</td>
            </tr>`;
        }

        if (data.length > 0) {
            data.forEach(call => {
                html += `<tr>
                    <td>${call.horario}</td>
                    <td>${call.duracao || "--"}</td>
                    <td>${call.origem}</td>
                    <td>${call.status}</td>
                </tr>`;
            });
        } else if (!status.rx_live) {
            html = '<tr><td colspan="4" style="text-align:center; padding:20px; color:#999;">Aguardando tráfego...</td></tr>';
        }

        document.getElementById('call-log').innerHTML = html;
    }).catch(() => {
        console.log('Erro ao carregar logs/status.');
    });
}


function loadWifiNetworks() {
    const select = document.getElementById('wifi_ssid');
    const hint = document.getElementById('wifi_hint');
    if (!select) return;
    hint.innerText = 'Buscando redes...';
    fetch('wifi_scan.php')
        .then(r => r.json())
        .then(items => {
            const current = select.dataset.current || select.value || '';
            select.innerHTML = '';
            if (!items.length) {
                const opt = document.createElement('option');
                opt.value = current;
                opt.textContent = current || 'Nenhuma rede encontrada';
                select.appendChild(opt);
                hint.innerText = 'Nenhuma rede encontrada agora.';
                return;
            }
            items.forEach(item => {
                const opt = document.createElement('option');
                opt.value = item.ssid;
                opt.textContent = item.ssid + ' - ' + item.signal + '%' + (item.security ? ' - ' + item.security : '');
                if (item.ssid === current || item.active) opt.selected = true;
                select.appendChild(opt);
            });
            hint.innerText = 'Selecione a rede, digite a senha e salve.';
        })
        .catch(() => {
            hint.innerText = 'Não consegui listar redes agora.';
        });
}

setInterval(updateStatus, 1000);
updateStatus();
setInterval(updateLogs, 1000);
updateLogs();    </script>

<div id="confirmModal" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,.65); z-index:9999; align-items:center; justify-content:center;">
  <div style="background:#1e1e1e; color:#fff; width:380px; max-width:90%; padding:25px; border-radius:14px; text-align:center; box-shadow:0 0 30px #000;">
    <div style="font-size:52px; color:#ffcc00;">⚠️</div>
    <h2>Confirmar alterações</h2>
    <p>Deseja salvar as configurações e reiniciar a repetidora agora?</p>
    <div style="display:flex; gap:10px; margin-top:20px;">
      <button type="button" onclick="closeConfirm()" style="flex:1; padding:12px; border:0; border-radius:8px; background:#555; color:white;">Cancelar</button>
      <button type="button" onclick="submitConfirm()" style="flex:1; padding:12px; border:0; border-radius:8px; background:#d9534f; color:white; font-weight:bold;">Salvar e Reiniciar</button>
    </div>
  </div>
</div>


<script>
let allowSubmit = false;
const cfgForm = document.getElementById('configForm');
if (cfgForm) {
  cfgForm.addEventListener('submit', function(e) {
    if (!allowSubmit) {
      e.preventDefault();
      document.getElementById('confirmModal').style.display = 'flex';
    }
  });
}
function closeConfirm() {
  document.getElementById('confirmModal').style.display = 'none';
}
function submitConfirm() {
  allowSubmit = true;
  const modal = document.getElementById('confirmModal');
  const panel = modal ? modal.querySelector('div') : null;
  if (panel) {
    panel.innerHTML = '<h2>Salvando configuracoes</h2><p>Aplicando ajustes e reiniciando a repetidora. Aguarde alguns segundos.</p><div class="saving-bar"><span></span></div>';
  }
  document.getElementById('configForm').submit();
}
</script>

    <div class="watermark">Produzido por PI | Desenvolvido por PU1DES</div>
</body>
</html>
