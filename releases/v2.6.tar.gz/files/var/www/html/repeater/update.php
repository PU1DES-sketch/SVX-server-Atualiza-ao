<?php
require_once __DIR__ . '/auth.php';
require_login();

$result = null;
$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'apply') {
    $result = shell_exec('sudo /usr/local/bin/repeater-update-apply 2>&1');
}

$raw = shell_exec('/usr/local/bin/repeater-update-check 2>&1');
$info = json_decode($raw, true);
if (!is_array($info)) {
    $error = $raw;
    $info = [
        'current' => trim(@file_get_contents('/etc/repeater/version')) ?: 'desconhecida',
        'latest' => 'indisponivel',
        'update_available' => false,
        'title' => '',
        'description' => '',
    ];
}
?>
<!doctype html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Atualizações</title>
<style>
body{font-family:Arial,sans-serif;background:#111827;color:#e5e7eb;margin:0;padding:22px}
a{color:#7dd3fc}.box{max-width:860px;background:#1f2937;border:1px solid #374151;border-radius:8px;padding:18px}
.ok{color:#22c55e}.warn{color:#facc15}.err{color:#f87171}
button{background:#2563eb;color:white;border:0;border-radius:7px;padding:10px 14px;font-weight:700}
pre{white-space:pre-wrap;background:#0b1220;border:1px solid #334155;border-radius:7px;padding:12px}
</style>
</head>
<body>
<div class="box">
<p><a href="index.php">Voltar</a></p>
<h1>Atualizações</h1>
<p>Versão instalada: <strong><?php echo htmlspecialchars($info['current']); ?></strong></p>
<p>Última versão: <strong><?php echo htmlspecialchars($info['latest']); ?></strong></p>
<?php if ($info['update_available']): ?>
  <p class="warn">Atualização disponível.</p>
  <h2><?php echo htmlspecialchars($info['title']); ?></h2>
  <p><?php echo nl2br(htmlspecialchars($info['description'])); ?></p>
  <form method="post"><input type="hidden" name="action" value="apply"><button>Atualizar agora</button></form>
<?php else: ?>
  <p class="ok">Sistema já está atualizado.</p>
<?php endif; ?>
<?php if ($error): ?><h2 class="err">Erro</h2><pre><?php echo htmlspecialchars($error); ?></pre><?php endif; ?>
<?php if ($result): ?><h2>Resultado</h2><pre><?php echo htmlspecialchars($result); ?></pre><?php endif; ?>
</div>
</body>
</html>
