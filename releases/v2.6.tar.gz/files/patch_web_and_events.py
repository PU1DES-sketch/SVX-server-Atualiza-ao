#!/usr/bin/env python3
import json
from pathlib import Path

INDEX = Path("/var/www/html/repeater/index.php")
SALVAR = Path("/var/www/html/repeater/salvar.php")
EVENTS = Path("/usr/share/svxlink/events.d/local/RepeaterLogic.tcl")
SUDOERS = Path("/etc/sudoers.d/repeater-update")


def patch_index():
    if not INDEX.exists():
        return
    txt = INDEX.read_text(encoding="utf-8", errors="ignore")
    if "time_announce_enabled" not in txt:
        marker = '<div class="field-group"><label>Senha Wi-Fi:'
        block = '''<div class="field-group"><label>Falar hora certa:</label><label class="checkline"><input type="checkbox" name="time_announce_enabled" value="1" <?php echo !empty($config['time_announce_enabled']) && $config['time_announce_enabled'] !== '0' ? 'checked' : ''; ?>> Habilitar anúncio de hora cheia</label></div>
                        '''
        txt = txt.replace(marker, block + marker, 1)
    if "update.php" not in txt:
        txt = txt.replace("Dashboard", "Dashboard", 1)
        txt = txt.replace("</nav>", ' | <a href="update.php">Atualizações</a></nav>', 1)
        if 'update.php' not in txt:
            txt = txt.replace("Sair", 'Atualizações</a> | <a href="logout.php">Sair', 1)
    INDEX.write_text(txt, encoding="utf-8")


def patch_salvar():
    if not SALVAR.exists():
        return
    txt = SALVAR.read_text(encoding="utf-8", errors="ignore")
    marker = "foreach ($_POST as $key => $value) {\n    $config[$key] = clean($value);\n}\n"
    insert = marker + "\n$config['time_announce_enabled'] = isset($_POST['time_announce_enabled']) ? '1' : '0';\n"
    if "time_announce_enabled" not in txt:
        txt = txt.replace(marker, insert, 1)
    SALVAR.write_text(txt, encoding="utf-8")


def patch_events():
    if not EVENTS.exists():
        return
    txt = EVENTS.read_text(encoding="utf-8", errors="ignore")
    if "bdnet_time_announce" not in txt:
        proc = r'''

proc bdnet_time_announce {} {
  set flag "/tmp/repeater_time_announce"
  if {![file exists $flag]} {
    return
  }
  variable repeater_is_up
  if {[info exists repeater_is_up] && $repeater_is_up == 1} {
    return
  }
  set wav [string trim [exec cat $flag]]
  if {[file exists $wav]} {
    puts "BDNET: falando hora certa $wav"
    playSilence 300
    playFile $wav
    playSilence 300
    file delete -force $flag
  }
}
'''
        txt = txt.replace("\nproc checkPeriodicIdentify {} {", proc + "\nproc checkPeriodicIdentify {} {", 1)
    old = "proc checkPeriodicIdentify {} {\n  Logic::checkPeriodicIdentify\n}"
    new = "proc checkPeriodicIdentify {} {\n  Logic::checkPeriodicIdentify\n  bdnet_time_announce\n}"
    if old in txt:
        txt = txt.replace(old, new, 1)
    EVENTS.write_text(txt, encoding="utf-8")


def patch_sudoers():
    SUDOERS.write_text(
        "www-data ALL=(root) NOPASSWD: /usr/local/bin/repeater-update-apply\n"
        "www-data ALL=(root) NOPASSWD: /usr/local/bin/repeater-update-check\n",
        encoding="utf-8",
    )
    SUDOERS.chmod(0o440)


patch_index()
patch_salvar()
patch_events()
patch_sudoers()
