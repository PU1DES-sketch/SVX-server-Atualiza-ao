#!/bin/sh
set -eu

VERSION="2.8"
BACKUP_DIR="/var/backups/repeater/update-$VERSION-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BACKUP_DIR"

backup_if_exists() {
  if [ -e "$1" ]; then
    mkdir -p "$BACKUP_DIR$(dirname "$1")"
    cp -a "$1" "$BACKUP_DIR$1"
  fi
}

backup_if_exists /var/www/html/repeater/index.php
backup_if_exists /var/www/html/repeater/salvar.php
backup_if_exists /var/www/html/repeater/update.php
backup_if_exists /var/www/html/repeater/backup.php
backup_if_exists /var/www/html/repeater/restore.php
backup_if_exists /usr/share/svxlink/events.d/local/RepeaterLogic.tcl
backup_if_exists /usr/local/bin/repeater_time_announce.py
backup_if_exists /usr/local/bin/repeater-update-check
backup_if_exists /usr/local/bin/repeater-update-apply
backup_if_exists /etc/systemd/system/repeater-time-announce.service
backup_if_exists /etc/systemd/system/repeater-time-announce.timer

install -m 755 files/usr/local/bin/repeater_time_announce.py /usr/local/bin/repeater_time_announce.py
install -m 755 files/usr/local/bin/repeater-update-check /usr/local/bin/repeater-update-check
install -m 755 files/usr/local/bin/repeater-update-apply /usr/local/bin/repeater-update-apply
install -m 644 files/etc/systemd/system/repeater-time-announce.service /etc/systemd/system/repeater-time-announce.service
install -m 644 files/etc/systemd/system/repeater-time-announce.timer /etc/systemd/system/repeater-time-announce.timer
install -o www-data -g www-data -m 644 files/var/www/html/repeater/update.php /var/www/html/repeater/update.php
install -o www-data -g www-data -m 644 files/var/www/html/repeater/backup.php /var/www/html/repeater/backup.php
install -o www-data -g www-data -m 644 files/var/www/html/repeater/restore.php /var/www/html/repeater/restore.php

python3 files/patch_web_and_events.py

if ! command -v espeak-ng >/dev/null 2>&1; then
  if command -v apt-get >/dev/null 2>&1; then
    timeout 120 apt-get update >/dev/null 2>&1 || true
    DEBIAN_FRONTEND=noninteractive timeout 180 apt-get install -y espeak-ng >/dev/null 2>&1 || true
  fi
fi

python3 - <<'PY'
import json
from pathlib import Path
path = Path("/etc/repeater/config.json")
data = json.loads(path.read_text() or "{}") if path.exists() else {}
data.setdefault("time_announce_enabled", "0")
path.write_text(json.dumps(data, indent=4, ensure_ascii=False))
PY

mkdir -p /etc/repeater
printf '%s\n' "$VERSION" >/etc/repeater/version

systemctl daemon-reload
systemctl enable --now repeater-time-announce.timer >/dev/null 2>&1 || true
systemctl restart svxlink 2>/dev/null || true

echo "Atualizacao $VERSION instalada."
echo "Backup: $BACKUP_DIR"
