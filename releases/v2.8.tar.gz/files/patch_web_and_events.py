#!/usr/bin/env python3
import json
from pathlib import Path

INDEX = Path("/var/www/html/repeater/index.php")
SALVAR = Path("/var/www/html/repeater/salvar.php")
EVENTS = Path("/usr/share/svxlink/events.d/local/RepeaterLogic.tcl")
SUDOERS = Path("/etc/sudoers.d/repeater-update")


def patch_index():
    if not INDEX.exists():
        return
    txt = INDEX.read_text(encoding="utf-8", errors="ignore")

    css_marker = ".btn-update { background: #34495e; color: white; border: none; padding: 5px 10px; border-radius: 3px; font-size: 10px; cursor: pointer; }"
    if ".wide-2" not in txt and css_marker in txt:
        txt = txt.replace(css_marker, css_marker + """
        .wide-2 { grid-column: span 2; }
        .full-width { grid-column: span 3; }
        .system-panel { background: #f8fafc; border: 1px solid #e5e7eb; border-radius: 5px; padding: 12px; }
        .system-row { display: flex; align-items: center; justify-content: space-between; gap: 14px; flex-wrap: wrap; }
        .system-title { font-size: 11px; font-weight: bold; color: #475569; margin-bottom: 8px; text-transform: uppercase; }
        .system-actions { display: flex; gap: 8px; flex-wrap: wrap; align-items: center; }
        .checkline { display: inline-flex; align-items: center; gap: 7px; font-size: 12px; color: #334155; font-weight: bold; }
        .checkline input { width: auto; }
""", 1)

    start = txt.find('<div class="section-head">Rede e Atualiza')
    if start != -1:
        end = txt.find('<button type="submit" class="btn-save">', start)
        if end != -1:
            block = '''<div class="section-head">Rede e Sistema</div>
                        <div class="field-group wide-2">
                            <label>Rede Wi-Fi:</label>
                            <div class="wifi-actions">
                                <select name="wifi_ssid" id="wifi_ssid" data-current="<?php echo htmlspecialchars($config['wifi_ssid'] ?? '', ENT_QUOTES); ?>">
                                    <option value="<?php echo htmlspecialchars($config['wifi_ssid'] ?? '', ENT_QUOTES); ?>"><?php echo htmlspecialchars(($config['wifi_ssid'] ?? '') ?: 'Buscar redes disponiveis'); ?></option>
                                </select>
                                <button type="button" class="btn-mini" onclick="loadWifiNetworks()">BUSCAR</button>
                            </div>
                            <span class="hint" id="wifi_hint">Se nao conectar em nenhum Wi-Fi no boot, o AP REPETIDOR-CONFIG sera ativado.</span>
                        </div>
                        <div class="field-group"><label>Senha Wi-Fi:</label><input type="password" name="wifi_pass" placeholder="Digite a senha da rede selecionada"></div>
                        <div class="field-group full-width system-panel">
                            <div class="system-title">Sistema</div>
                            <div class="system-row">
                                <label class="checkline"><input type="checkbox" name="time_announce_enabled" value="1" <?php echo !empty($config['time_announce_enabled']) && $config['time_announce_enabled'] !== '0' ? 'checked' : ''; ?>> Falar hora certa a cada hora</label>
                                <div class="system-actions">
                                    <button type="button" class="btn-update" onclick="window.location.href='update.php'">BUSCAR ATUALIZACOES</button>
                                    <button type="button" class="btn-update" onclick="window.location.href='backup.php'">BACKUP</button>
                                    <button type="button" class="btn-update" onclick="window.location.href='restore.php'">RESTAURAR BACKUP</button>
                                    <button type="button" class="btn-update" onclick="window.location.href='senha.php'">ALTERAR SENHA</button>
                                </div>
                            </div>
                        </div>
                        '''
            txt = txt[:start] + block + txt[end:]
    INDEX.write_text(txt, encoding="utf-8")


def patch_salvar():
    if not SALVAR.exists():
        return
    txt = SALVAR.read_text(encoding="utf-8", errors="ignore")
    marker = "foreach ($_POST as $key => $value) {\n    $config[$key] = clean($value);\n}\n"
    insert = marker + "\n$config['time_announce_enabled'] = isset($_POST['time_announce_enabled']) ? '1' : '0';\n"
    if "time_announce_enabled" not in txt:
        txt = txt.replace(marker, insert, 1)
    SALVAR.write_text(txt, encoding="utf-8")


def patch_events():
    if not EVENTS.exists():
        return
    txt = EVENTS.read_text(encoding="utf-8", errors="ignore")
    if "bdnet_time_announce" not in txt:
        proc = r'''

proc bdnet_time_announce {} {
  set flag "/tmp/repeater_time_announce"
  if {![file exists $flag]} {
    return
  }
  variable repeater_is_up
  if {[info exists repeater_is_up] && $repeater_is_up == 1} {
    return
  }
  set wav [string trim [exec cat $flag]]
  if {[file exists $wav]} {
    puts "BDNET: falando hora certa $wav"
    playSilence 300
    playFile $wav
    playSilence 300
    file delete -force $flag
  }
}
'''
        txt = txt.replace("\nproc checkPeriodicIdentify {} {", proc + "\nproc checkPeriodicIdentify {} {", 1)
    old = "proc checkPeriodicIdentify {} {\n  Logic::checkPeriodicIdentify\n}"
    new = "proc checkPeriodicIdentify {} {\n  Logic::checkPeriodicIdentify\n  bdnet_time_announce\n}"
    if old in txt:
        txt = txt.replace(old, new, 1)
    EVENTS.write_text(txt, encoding="utf-8")


def patch_sudoers():
    SUDOERS.write_text(
        "www-data ALL=(root) NOPASSWD: /usr/local/bin/repeater-update-apply\n"
        "www-data ALL=(root) NOPASSWD: /usr/local/bin/repeater-update-check\n"
        "www-data ALL=(root) NOPASSWD: /usr/local/bin/repeater-backup\n"
        "www-data ALL=(root) NOPASSWD: /usr/local/bin/repeater-restore *\n",
        encoding="utf-8",
    )
    SUDOERS.chmod(0o440)


patch_index()
patch_salvar()
patch_events()
patch_sudoers()
