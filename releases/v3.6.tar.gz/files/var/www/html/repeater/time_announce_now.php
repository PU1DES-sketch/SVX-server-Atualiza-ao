<?php
require_once "auth.php";
require_login();
header('Content-Type: application/json; charset=utf-8');
$out = [];
$rc = 0;
exec('sudo /usr/local/bin/repeater_time_announce.py --now --play-direct 2>&1', $out, $rc);
if ($rc === 0) {
    echo json_encode(['ok' => true, 'message' => 'Hora certa falada agora.', 'output' => implode("\n", $out)], JSON_UNESCAPED_UNICODE);
} elseif ($rc === 2) {
    echo json_encode(['ok' => false, 'message' => 'Repetidora ocupada. Tente novamente quando estiver em repouso.', 'output' => implode("\n", $out)], JSON_UNESCAPED_UNICODE);
} else {
    echo json_encode(['ok' => false, 'message' => 'Nao consegui tocar direto. O audio foi preparado para o proximo ciclo do SvxLink.', 'output' => implode("\n", $out)], JSON_UNESCAPED_UNICODE);
}
